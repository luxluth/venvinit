"""
venvinit
~~~~~~~~
venvinit is a tool to create a virtual environment and install packages
from a requirements file.

:copyright (c) 2022 LuxLuth
:license: MIT, see LICENSE for more details.
"""

__title__ = 'venvinit'
__author__ = 'LuxLuth'
__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2022 LuxLuth'
__version__ = '0.0.2'
